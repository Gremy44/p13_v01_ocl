#!D:\PRO\CODE\Formation_OpenClassrooms\p13_v01\p13_v01_ocl\env\Scripts\python.exe
from django.core import management

if __name__ == "__main__":
    management.execute_from_command_line()
