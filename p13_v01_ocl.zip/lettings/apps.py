from django.apps import AppConfig


class LettingsConfig(AppConfig):
    name = 'lettings'
