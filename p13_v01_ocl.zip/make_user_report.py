import os
import requests
import dotenv
import json

dotenv.load_dotenv()

# L'URL de l'API que vous souhaitez appeler
api_url = "https://sentry.io/api/0/projects/myself-wq0/orange-county-lettings/issues/?&id/"

# Remplacez "your_bearer_token" par votre propre jeton d'accès Bearer
bearer_token = os.getenv("API_KEY_SENTRY")

# Définir les en-têtes avec le token d'authentification
headers = {
    "Authorization": f"Bearer {bearer_token}"
}

# Faire la requête GET à l'API avec les en-têtes
response = requests.get(api_url, headers=headers)

# Vérifier si la requête a réussi
if response.status_code == 200:
    data = response.json()  # Récupérer les données de la réponse
    # ecrire le fichier json
    with open('rapport.json', 'w') as outfile:
        json.dump(data, outfile)
else:
    print("La requête a échoué avec le code de statut:", response.status_code)
    print("Contenu de la réponse:", response.text)
